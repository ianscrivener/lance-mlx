"""Modality-Aware Positional Encoding (MaPE).

Per Lance paper §3.3 verbatim:
    "MaPE then applies a modality-specific offset Δ_m only along the temporal
    dimension: p^(m)_{t,h,w} = p̂^(m)_{t,h,w} + [Δ_m, 0, 0]"

This is a one-line modification to Qwen2.5-VL's 3D RoPE: add a per-position-group
constant to the temporal axis of (t, h, w) coordinates before computing rotations.

Open questions (resolve in Phase 1a by inspecting safetensors keys):
1. Are Δ_m values LEARNED (present as parameters in the checkpoint)
   or HARD-CODED constants from llm_config.json?
2. If learned, what's the parameter name? Likely `mape.delta_m` or
   `model.mape_offsets`.
3. How many position groups are there exactly? Paper text implies 4
   (text + ViT-semantic + clean VAE + noisy VAE) but the architecture
   may collapse text+ViT into one group with offset 0.
"""

from __future__ import annotations

import mlx.core as mx
import mlx.nn as nn


class MaPEOffsets(nn.Module):
    """Holds the Δ_m table.

    If the upstream checkpoint stores these as learned parameters, set
    `learned=True` and `from_safetensors` will populate them. Otherwise
    initialize from llm_config.json constants.
    """

    def __init__(self, num_groups: int = 4, learned: bool = False):
        super().__init__()
        if learned:
            # TODO(claude-code): match the upstream tensor name. Common candidates:
            #   "model.mape_offsets" or "mape.delta_m"
            self.delta_m = mx.zeros((num_groups,))
        else:
            # Constants — values to be filled from llm_config.json once read
            self.delta_m = mx.zeros((num_groups,))


def apply_mape_position_ids(
    position_ids: mx.array,  # (B, T, 3) — (t, h, w) coordinates
    position_group: mx.array,  # (B, T) int in {0..num_groups-1}
    delta_m: mx.array,  # (num_groups,) temporal offsets
) -> mx.array:
    """Add per-group temporal offset to position IDs before RoPE.

    Args:
        position_ids: (B, T, 3) raw (t, h, w) coordinates
        position_group: (B, T) which modality group each token belongs to
        delta_m: (num_groups,) lookup table of temporal offsets

    Returns:
        (B, T, 3) — same shape, with temporal axis (index 0) shifted by Δ_m
    """
    t_offset = delta_m[position_group]  # (B, T)
    out = mx.array(position_ids)  # copy
    out[..., 0] = out[..., 0] + t_offset
    return out


# TODO(claude-code): wire this into mlx-vlm's Qwen2.5-VL 3D RoPE. The clean
# integration is to add `position_group` and `delta_m` as optional args to
# the existing rope() call and apply the offset before computing sin/cos.
