"""Dual-expert Mixture-of-Transformer-Experts backbone for Lance.

Architecture summary (from paper §3.2 + §5.1):
    - 36 transformer layers
    - Hidden dim 2048, intermediate 11008 (Qwen2.5-3B-LLM dims)
    - 16 attention heads, 2 KV heads (GQA)
    - RMSNorm, RoPE (with MaPE modification)
    - Per-expert separate: FFN, output projection, QK-Norm
    - Shared: attention QKV projection (paper says "shared attention substrate"),
      input embeddings, LM head (with untied lm_head weight on Lance vs tied on Qwen)

Open questions to resolve in Phase 1a:
1. Does each layer have its own pair of QK-norms? (Likely yes — "QK-Norm modules"
   is plural in the paper.)
2. Are attention QKV projections truly shared across UND/GEN, or duplicated?
   Paper says "shared attention substrate" which is ambiguous — could mean
   shared parameters, or shared computational pattern with separate parameters.
   Inspect key names in safetensors to confirm.
3. Is there a residual connection BETWEEN experts at each layer, or do tokens
   only see their assigned expert's output?
"""

from __future__ import annotations

import mlx.core as mx
import mlx.nn as nn

from .routing import expert_mask_from_position_group, merge_expert_outputs


class LanceMoTLayer(nn.Module):
    """One dual-expert transformer layer.

    TODO(claude-code): this is structural pseudocode. Fill in the actual
    submodule construction once Phase 1a confirms the safetensors topology.
    """

    def __init__(self, config: dict):
        super().__init__()
        self.hidden_dim = config["hidden_size"]
        # Shared attention (per paper). If Phase 1a shows separate QKV per
        # expert, duplicate this.
        # self.attn = SharedAttention(config)

        # Per-expert QK-Norms
        # self.qk_norm_und = nn.RMSNorm(config["head_dim"])
        # self.qk_norm_gen = nn.RMSNorm(config["head_dim"])

        # Per-expert FFNs (SwiGLU)
        # self.ffn_und = SwiGLU(config)
        # self.ffn_gen = SwiGLU(config)

        # Per-expert output projections
        # self.o_proj_und = nn.Linear(config["hidden_size"], config["hidden_size"], bias=False)
        # self.o_proj_gen = nn.Linear(config["hidden_size"], config["hidden_size"], bias=False)

        # Pre-attn / pre-FFN RMSNorms (likely shared but confirm)
        # self.input_norm = nn.RMSNorm(config["hidden_size"])
        # self.post_attn_norm = nn.RMSNorm(config["hidden_size"])

    def __call__(
        self,
        h: mx.array,
        position_ids: mx.array,
        position_group: mx.array,
        attention_mask: mx.array | None = None,
        kv_cache: tuple | None = None,
    ) -> mx.array:
        """
        Args:
            h: (B, T, D)
            position_ids: (B, T, 3) — (t, h, w) coordinates for MaPE-RoPE
            position_group: (B, T) — modality group, drives expert routing
            attention_mask: optional causal/structured mask
            kv_cache: optional KV cache for incremental decoding

        Returns:
            (B, T, D) output hidden state
        """
        expert_mask = expert_mask_from_position_group(position_group)

        # TODO(claude-code): implement
        # 1. h_norm = self.input_norm(h)
        # 2. attn_out = self.attn(h_norm, position_ids, position_group, attention_mask, kv_cache,
        #                         qk_norm_und=self.qk_norm_und, qk_norm_gen=self.qk_norm_gen)
        # 3. Apply per-expert output projection
        #    o_und = self.o_proj_und(attn_out)
        #    o_gen = self.o_proj_gen(attn_out)
        #    attn_out = merge_expert_outputs(o_und, o_gen, expert_mask)
        # 4. h = h + attn_out
        # 5. h_norm = self.post_attn_norm(h)
        # 6. ffn_und = self.ffn_und(h_norm)
        #    ffn_gen = self.ffn_gen(h_norm)
        #    ffn_out = merge_expert_outputs(ffn_und, ffn_gen, expert_mask)
        # 7. return h + ffn_out
        raise NotImplementedError("LanceMoTLayer — fill in after Phase 1a key inspection")


class LanceModel(nn.Module):
    """Full Lance LLM backbone — 36 LanceMoTLayer + embeddings + LM head.

    Does NOT include the ViT or VAE — those are separate modules vendored from
    mlx-vlm and mlx-video respectively. See lance_mlx.pipeline.* for the full
    inference orchestration.
    """

    def __init__(self, config: dict):
        super().__init__()
        # self.embed_tokens = nn.Embedding(config["vocab_size"], config["hidden_size"])
        # self.layers = [LanceMoTLayer(config) for _ in range(config["num_hidden_layers"])]
        # self.final_norm = nn.RMSNorm(config["hidden_size"])
        # IMPORTANT: Lance UNTIES the LM head from input embeddings (Qwen2.5-3B ties them).
        # self.lm_head = nn.Linear(config["hidden_size"], config["vocab_size"], bias=False)
        ...

    def __call__(
        self,
        input_ids: mx.array,
        position_ids: mx.array,
        position_group: mx.array,
        attention_mask: mx.array | None = None,
    ) -> tuple[mx.array, mx.array]:
        """
        Returns:
            logits: (B, T, vocab_size) — for autoregressive next-token over UND positions
            hidden_states: (B, T, hidden_size) — fed to flow head over GEN positions
        """
        raise NotImplementedError("LanceModel — fill in after Phase 1a key inspection")
