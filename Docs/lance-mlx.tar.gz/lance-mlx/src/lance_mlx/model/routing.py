"""Token modality routing for Lance's dual-expert MoT.

Lance does NOT use a learned router (no softmax gate, no top-k). Routing is
deterministic from token metadata:

    Modality group        → Expert tower    → Position-group ID for MaPE
    ─────────────────────────────────────────────────────────────────────
    text                  → LLM_UND         → 0 (text)
    ViT semantic (image)  → LLM_UND         → 1 (ViT-semantic)
    ViT semantic (video)  → LLM_UND         → 1 (ViT-semantic)
    Clean VAE latent      → LLM_GEN         → 2 (clean VAE)
    Noisy VAE latent      → LLM_GEN         → 3 (noisy VAE)

A "modality_mask" tensor of shape (B, T) carries the expert assignment
(0=UND, 1=GEN) and is used to gate FFN/output-projection outputs in
LanceMoTLayer. A separate "position_group" tensor of shape (B, T) carries the
MaPE bucket (0..3).

TODO(claude-code): once we know the exact special-token IDs from
tokenizer.json (BOT/EOT/BOV/EOV), implement build_modality_mask() to derive
these masks from raw token IDs + segment metadata. Until then, callers
construct masks explicitly during sequence assembly.
"""

from __future__ import annotations

from enum import IntEnum

import mlx.core as mx


class Expert(IntEnum):
    UND = 0
    GEN = 1


class PositionGroup(IntEnum):
    TEXT = 0
    VIT_SEMANTIC = 1
    CLEAN_VAE = 2
    NOISY_VAE = 3


# Reverse map: which expert handles which position group?
POSITION_GROUP_TO_EXPERT: dict[int, int] = {
    PositionGroup.TEXT: Expert.UND,
    PositionGroup.VIT_SEMANTIC: Expert.UND,
    PositionGroup.CLEAN_VAE: Expert.GEN,
    PositionGroup.NOISY_VAE: Expert.GEN,
}


def expert_mask_from_position_group(position_group: mx.array) -> mx.array:
    """Derive expert routing mask from position-group IDs.

    Args:
        position_group: (B, T) int array with values in {0..3}.

    Returns:
        (B, T) int array with values in {0, 1} — 0 if token routes to LLM_UND,
        1 if it routes to LLM_GEN.
    """
    # TODO(claude-code): replace with mx.take once the routing tensor is finalized;
    # for now use the algebraic shortcut that PositionGroup ≥ 2 → GEN.
    return (position_group >= PositionGroup.CLEAN_VAE).astype(mx.int32)


def merge_expert_outputs(
    out_und: mx.array,
    out_gen: mx.array,
    expert_mask: mx.array,
) -> mx.array:
    """Select per-token output from the matching expert.

    Args:
        out_und: (B, T, D) output from LLM_UND tower
        out_gen: (B, T, D) output from LLM_GEN tower
        expert_mask: (B, T) int in {0, 1}

    Returns:
        (B, T, D) merged output.
    """
    # broadcast mask to (B, T, 1) for selection
    sel = expert_mask[..., None].astype(out_und.dtype)
    return out_und * (1 - sel) + out_gen * sel
