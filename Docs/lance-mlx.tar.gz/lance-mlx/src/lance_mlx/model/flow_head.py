"""Flow-matching velocity prediction head.

Takes LLM_GEN hidden states for noisy-VAE-latent tokens and predicts velocity
(x_1 - x_0) under the linear interpolant flow x_t = t*x_1 + (1-t)*x_0.

Structure (TBD in Phase 1a):
    Paper does not explicitly diagram the flow head. Plausible candidates,
    from simplest to most elaborate:

    (a) Linear projection: nn.Linear(hidden_dim, vae_latent_channels)
    (b) MLP: Linear → SiLU → Linear → output_dim
    (c) Thin DiT block: Norm → CrossAttn(text_embeds) → AdaLN(t) → MLP
    (d) Sinusoidal-time-conditioned MLP with time-embed concatenation

Inspect the safetensors key list in Phase 1a to confirm. Common upstream names:
    "flow_head.*", "velocity_head.*", "decoder.*", "gen_head.*"

Standard Wan2.2-derived flow heads use option (b) or (c); BAGEL uses (c).
Default to (b) until confirmed.
"""

from __future__ import annotations

import mlx.core as mx
import mlx.nn as nn


class FlowHead(nn.Module):
    """Predicts flow-matching velocity from LLM_GEN hidden states.

    Output shape: matches Wan2.2 VAE latent channels (16 for both image and video).
    """

    def __init__(self, hidden_dim: int = 2048, latent_channels: int = 16,
                 intermediate_dim: int | None = None):
        super().__init__()
        intermediate_dim = intermediate_dim or hidden_dim
        # TODO(claude-code): replace with the actual upstream structure once
        # Phase 1a reveals it. This default is option (b) — MLP.
        self.proj_in = nn.Linear(hidden_dim, intermediate_dim, bias=False)
        self.act = nn.SiLU()
        self.proj_out = nn.Linear(intermediate_dim, latent_channels, bias=False)

    def __call__(self, h: mx.array, t: mx.array | None = None) -> mx.array:
        """
        Args:
            h: (B, T_latent, hidden_dim) — LLM_GEN hidden states at noisy-VAE positions
            t: (B,) or (B, T_latent) timestep — for time conditioning
               (unused in option (b); needed for options (c)/(d))

        Returns:
            (B, T_latent, latent_channels) velocity prediction
        """
        # TODO(claude-code): add time conditioning if upstream structure is (c)/(d)
        return self.proj_out(self.act(self.proj_in(h)))
