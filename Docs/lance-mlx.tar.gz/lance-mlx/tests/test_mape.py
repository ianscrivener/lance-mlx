"""Unit tests for lance_mlx.model.mape — Modality-Aware Positional Encoding offset."""

from __future__ import annotations

import mlx.core as mx

from lance_mlx.model.mape import apply_mape_position_ids


def test_apply_mape_no_offset_when_delta_zero():
    """Δ_m = 0 should be a no-op."""
    pos = mx.array([[[0, 1, 2], [3, 4, 5]]])  # (1, 2, 3)
    pg = mx.array([[0, 0]])
    delta_m = mx.zeros((4,))
    out = apply_mape_position_ids(pos, pg, delta_m)
    assert mx.array_equal(out, pos)


def test_apply_mape_offset_only_on_temporal_axis():
    """Verify only the t-coordinate (index 0) is shifted; h and w untouched."""
    pos = mx.array([[[0, 10, 20], [0, 30, 40]]])
    pg = mx.array([[2, 2]])  # clean VAE → uses delta_m[2]
    delta_m = mx.array([0.0, 0.0, 100.0, 0.0])
    out = apply_mape_position_ids(pos, pg, delta_m)
    # t should shift by +100; h, w unchanged
    expected = mx.array([[[100, 10, 20], [100, 30, 40]]])
    assert mx.array_equal(out, expected)


def test_apply_mape_per_token_group_offsets():
    """Different position groups get different temporal offsets."""
    pos = mx.array([[[0, 0, 0], [0, 0, 0], [0, 0, 0]]])
    pg = mx.array([[0, 2, 3]])  # text, clean VAE, noisy VAE
    delta_m = mx.array([0.0, 10.0, 200.0, 500.0])
    out = apply_mape_position_ids(pos, pg, delta_m)
    expected_t = mx.array([[0, 200, 500]])  # delta_m[pg]
    assert mx.array_equal(out[..., 0], expected_t)
